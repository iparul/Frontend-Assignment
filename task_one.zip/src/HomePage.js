import { useState, useEffect } from "react";
import img1 from "../src/Imgs/img1.png";
import logo from "../src/Imgs/logo1.png";
import "./App.css";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { useNavigate } from "react-router-dom";
function HomePage() {
  const navigate = useNavigate();
  const initialState = { userEmail: "", mobile: "" };
  const [formValues, setFormValues] = useState(initialState);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...formValues, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    // debugger;
    setFormErrors(validate(formValues));
    setIsSubmit(true);
  };

  useEffect(() => {
    if (Object.keys(formErrors).length === 0 && isSubmit) {
      console.log(formValues);
      navigate("/thanks", { state: formValues });
    }
  }, [formErrors]);
  const validate = (values) => {
    const errors = {};
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    if (!values.userEmail) {
      errors.userEmail = "Email is required!";
    } else if (!regex.test(values.userEmail)) {
      errors.userEmail = "You have entered an invalid email address!";
    }
    if (!values.mobile) {
      errors.mobile = "Mobile is required!";
    } else if (values.mobile.length < 12 || values.mobile.length > 12) {
      errors.mobile = "You have entered an invalid Mobile number!";
    }
    return errors;
  };
  return (
    <div className="App">
      <div>
        <img src={img1} className="img1" />
      </div>
      <div className="right_texts">
        <img src={logo} style={{ width: "70%" }} className="logo" />
        <h1 className="first_text">Get a FREE</h1>
        <h2 className="second_text">consultation with an expert</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Enter your email"
            name="userEmail"
            value={formValues.userEmail}
            onChange={handleChange}
            className="inputSize"
          />
          <p style={{ color: "red" }}>{formErrors.userEmail}</p>

          {/* <input
            type="mobile"
            name="mobile"
            placeholder="Enter your mobile"
            value={formValues.mobile}
            onChange={handleChange}
            className="inputSize"
          /> */}
          <PhoneInput
            type="mobile"
            name="mobile"
            placeholder="Enter phone mobile"
            value={formValues.mobile}
            onChange={(mobile) =>
              setFormValues({ ...formValues, mobile: mobile })
            }
          />
          <p style={{ color: "red" }}>{formErrors.mobile}</p>
          <button className="button">Talk to Us →</button>
        </form>
      </div>
    </div>
  );
}

export default HomePage;
