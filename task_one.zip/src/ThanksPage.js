import React from "react";
import { useLocation } from "react-router-dom";

function ThanksPage() {
  const location = useLocation();
  console.log("location.state", location.state);
  return (
    <div className="headerThanks">
      <div style={{ marginTop: "117px", fontWeight: "700" }}>
        Thanks a ton for taking out your precious time and for completing the
        survey
      </div>
      <div style={{ marginTop: "40px" }}>
        <span style={{ fontWeight: "700" }}>Email Address</span>{" "}
        <span>{location.state.userEmail}</span>
      </div>
      <div style={{ marginTop: "40px" }}>
        <span style={{ fontWeight: "700" }}>Contact Number</span>{" "}
        <span>+{location.state.mobile}</span>
      </div>
    </div>
  );
}

export default ThanksPage;
