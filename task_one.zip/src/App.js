import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import HomePage from "./HomePage";
import ThanksPage from "./ThanksPage";

function App() {
  return (
    <div className="webapp">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} extact />
          <Route path="/thanks" element={<ThanksPage />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
